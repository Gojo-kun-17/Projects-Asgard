# Intelligent Travel Assistant AI

## Project Overview
The Intelligent Travel Assistant AI is a complete, end-to-end Python project designed to act as a smart travel companion. When a user queries a destination, the AI fetches the real-time weather using external APIs and generates a curated list of top attractions via dynamic web search. This project utilizes the modern LangChain framework to power a precise "**Tool-Calling Agent**," showcasing how Large Language Models (LLMs) can bridge contextual understanding with functional programming logic.

## Architecture Explanation
The project is built on a modular "Tool-Calling" architecture using LangChain:
1. **LLM Engine:** The reasoning core of the application utilizes OpenAI's GPT models via `ChatOpenAI` (can easily be swapped to Google's Gemini models). The model uses a low temperature (0.2) to maintain factual consistency over creative hallucination.
2. **LangChain Tool Calling:** The application uses LangChain's `@tool` decorator to define functional capabilities strictly bound to signatures (Docstrings and argument types).
    - `get_current_weather`: Leverages the `requests` library to query `api.weatherapi.com` for precise real-time weather metrics.
    - `get_tourist_attractions`: Wraps LangChain's `DuckDuckGoSearchResults` community tool to rapidly fetch web snippets of attractions.
3. **Agent & Executor:** Instead of using deprecated chains, the system implements `create_tool_calling_agent`. The `AgentExecutor` manages the cyclical workflow of interpreting user requests, mapping requests to tools, waiting for tool execution, and passing outputs back into the LLM's context window.

## Reasoning Explanation (How the LLM Decides)
The AI uses advanced **Function Calling / Tool Calling** capabilities intrinsic to advanced LLMs. The process is completely autonomous once the prompt and tools are initialized:
1. **Analysis:** The `AgentExecutor` passes the user's input alongside the tool definitions to the LLM. 
2. **Tool Selection:** The LLM reads the defined docstrings representing what each tool does (e.g., "Always use this tool when a user asks about the weather...").
3. **Interruption & Execution:** The LLM does not generate plain text immediately; instead, it outputs an internal JSON directive asking to invoke `get_current_weather("Paris")` and `get_tourist_attractions("Paris")`.
4. **Scratchpad:** The `AgentExecutor` runs these underlying Python tools. It captures the string outputs and appends them to the `agent_scratchpad` list as new messages. 
5. **Synthesis:** The LLM, now fully aware of the facts, acts on its system prompt instructions to synthesize a friendly, structured output.

## Code Flow Explanation
1. **Initialization:** `load_dotenv()` runs first to ingest API keys securely from the local `.env` file.
2. **LLM & Tool Definition:** Instances of `ChatOpenAI` and custom local tools are initialized in `main.py`.
3. **Prompt Template:** `ChatPromptTemplate` is structured with a "system" personality prompt, human inputs, and a crucial `MessagesPlaceholder("agent_scratchpad")` strictly necessary for tool-calling memory trace.
4. **Agent Binding:** `create_tool_calling_agent` takes the LLM, the tools list, and the prompt, combining them into an executable runnable agent.
5. **Runtime Executor:** `AgentExecutor` wraps the agent, equipped with specific debugging (`verbose=True`).
6. **Interaction Loop:** The standard out console continuously listens for queries. User inputs enter the logic pool using `agent_executor.invoke({"input": user_query})`.

## Technologies Used
* **Python 3.x:** Core runtime language.
* **LangChain Ecosystem:** (`langchain`, `langchain-openai`, `langchain-community`, `langchain-core`): Used to wire together LLM logic with function calling and predefined abstractions.
* **OpenAI API:** Serves as the base model for intelligent entity processing and natural language synthesis.
* **WeatherAPI.com:** REST service queried natively via the `requests` module to parse geographic and meteorological data.
* **DuckDuckGo Search:** Implemented implicitly via `langchain-community` for frictionless, keyless web search scraping.
* **python-dotenv:** Environment variable parser designed to decouple sensitive data from logical structures.
