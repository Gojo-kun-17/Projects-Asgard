import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.agents import create_tool_calling_agent, AgentExecutor

# Import the custom tools we defined
from tools import get_current_weather, get_tourist_attractions

def main():
    # Load environment variables from .env file
    load_dotenv()
    
    print("======================================================")
    print("✈️  Welcome to the Intelligent Travel Assistant AI 🌍")
    print("======================================================")
    
    # Ensure API keys are present before starting
    if not os.getenv("OPENAI_API_KEY"):
        print("\n[WARNING] OPENAI_API_KEY is not set. Please define it in your .env file.")
        print("Falling back to instructions... please set the key to run the agent.\n")
        return
        
    if not os.getenv("WEATHER_API_KEY"):
        print("\n[WARNING] WEATHER_API_KEY is not set. The weather tool will return errors.")

    # 1. Initialize the LLM
    # Here we use OpenAI's model. Alternatively, you can use ChatGoogleGenerativeAI from langchain_google_genai
    # Example for Gemini support: 
    # from langchain_google_genai import ChatGoogleGenerativeAI
    # llm = ChatGoogleGenerativeAI(model="gemini-1.5-pro", temperature=0.2)
    
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.2)
    
    # 2. Define the tools
    tools = [get_current_weather, get_tourist_attractions]
    
    # 3. Create the prompt
    # The system prompt instructs the LLM on its persona and dictates how to use its tools
    prompt = ChatPromptTemplate.from_messages([
        ("system", """You are an intelligent, friendly, and highly capable Travel Assistant AI. 
                      Your goal is to help users plan trips by providing accurate current weather 
                      and top tourist attractions for their requested destination.
                      
                      CRITICAL INSTRUCTIONS:
                      1. You MUST always use the `get_current_weather` tool to check the weather.
                      2. You MUST always use the `get_tourist_attractions` tool to discover interesting places.
                      3. Compile the outputs from both tools into a beautifully formatted, enthusiastic, 
                         and readable travel guide response."""),
        ("human", "{input}"),
        MessagesPlaceholder(variable_name="agent_scratchpad"),
    ])
    
    # 4. Create the Tool Calling Agent
    # This replaces deprecated functions like initialize_agent()
    agent = create_tool_calling_agent(llm, tools, prompt)
    
    # 5. Create the Agent Executor
    # This manages the runtime observation loop (tool invoking and response feeding)
    agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)
    
    # 6. User Interaction Loop
    while True:
        destination = input("\nEnter a destination city (or type 'quit' to exit): ").strip()
        
        if destination.lower() in ['quit', 'exit', 'q']:
            print("Thank you for using the Travel Assistant AI. Safe travels! ✈️")
            break
        
        if not destination:
            print("Please enter a valid destination name.")
            continue
            
        print(f"\n[Agent] Looking up weather and attractions for {destination}...\n")
        
        try:
            # Invoke the agent executor with the user's input
            response = agent_executor.invoke({"input": f"Tell me about the weather and attractions in {destination}"})
            
            print("\n" + "="*50)
            print("🌟 TRAVEL ASSISTANT RESPONSE")
            print("="*50)
            print(response["output"])
            print("="*50)
            
        except Exception as e:
            print(f"\nAn error occurred while communicating with the LangChain Agent: {e}")

if __name__ == "__main__":
    main()
