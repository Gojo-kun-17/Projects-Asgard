import os
import requests
from langchain_core.tools import tool
from langchain_community.tools import DuckDuckGoSearchResults

@tool
def get_current_weather(location: str) -> str:
    """
    Fetch the current weather information for a specified location (destination city).
    Always use this tool when a user asks about the weather in a city or destination.
    """
    api_key = os.getenv("WEATHER_API_KEY")
    if not api_key:
        return "Error: WEATHER_API_KEY environment variable is not set. Please set it in the .env file."

    # Using weatherapi.com current weather endpoint
    url = f"http://api.weatherapi.com/v1/current.json?key={api_key}&q={location}&aqi=no"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        
        location_name = data["location"]["name"]
        country = data["location"]["country"]
        temp_c = data["current"]["temp_c"]
        condition = data["current"]["condition"]["text"]
        humidity = data["current"]["humidity"]
        wind_kph = data["current"]["wind_kph"]
        
        return f"Weather in {location_name}, {country}: {condition}, {temp_c}°C, Humidity: {humidity}%, Wind: {wind_kph} km/h."
    except requests.exceptions.HTTPError as e:
        if response.status_code == 401:
            return "Error: Invalid WeatherAPI key."
        elif response.status_code == 400:
            return f"Error: Location '{location}' not found by the weather service."
        return f"Failed to fetch weather data: {str(e)}"
    except Exception as e:
        return f"An unexpected error occurred while fetching weather for {location}: {str(e)}"


@tool
def get_tourist_attractions(location: str) -> str:
    """
    Discover the top tourist attractions, landmarks, and interesting places to visit in a specified destination city.
    Always use this tool to find things to do when a user queries a destination.
    """
    try:
        # We use DuckDuckGo search to find top tourist attractions
        search = DuckDuckGoSearchResults(num_results=5)
        query = f"top tourist attractions things to do in {location}"
        
        results = search.run(query)
        
        if not results:
            return f"No attractions found for {location}."
            
        return f"Top attractions information for {location}:\n{results}"
    except Exception as e:
        return f"Failed to fetch attractions for {location} using search tool: {str(e)}"
