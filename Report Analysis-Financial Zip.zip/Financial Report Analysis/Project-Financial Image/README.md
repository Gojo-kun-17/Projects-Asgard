# AI-Powered Financial Image Scan & Financial Report Analysis

Builds an AI system to process financial document images (annual reports, balance sheets, income statements), extract data using OCR, analyze trends, and generate comprehensive insights. 

## Features
- **OCR Text Extraction:** Uses `pytesseract` to read images.
- **Image Processing:** OpenCV for grayscale conversion and chart edge detection.
- **Metric Extraction:** Locates and parses KPIs (Revenue, Net Income, etc.).
- **Interactive UI:** Features `ipywidgets` for Investor vs. Auditor toggle modes.
- **Automated AI Summaries:** Harnesses the OpenAI API for an executive-level breakdown.

## Prerequisites
You **must** have Tesseract-OCR installed on your system.
- Download it here: https://github.com/UB-Mannheim/tesseract/wiki
- Ensure it is added to your system `PATH`, or update the direct path in the notebook's first code cell.

## Installation
1. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
2. For OpenAI integration (optional but recommended for "Bonus Features"):
   Create a `.env` file in the project root:
   ```
   OPENAI_API_KEY=your_key_here
   ```

## Running the Notebook
Execute all cells sequentially from top to bottom. The widget interactives are at the very end.
Note: Run `generate_test_images.py` if the `sample_images` directory is empty.