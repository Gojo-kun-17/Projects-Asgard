import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import os

os.makedirs('sample_images', exist_ok=True)

# 1. Generate Balance Sheet Image
fig, ax = plt.subplots(figsize=(6, 4))
ax.axis('tight')
ax.axis('off')
data = [
    ["Assets", "$1,000,000"],
    ["Liabilities", "$400,000"],
    ["Equity", "$600,000"]
]
df = pd.DataFrame(data, columns=["Item", "Amount"])
table = ax.table(cellText=df.values, colLabels=df.columns, loc='center', cellLoc='left')
table.scale(1, 2)
table.set_fontsize(14)
plt.title("Balance Sheet 2023", fontsize=16)
plt.savefig('sample_images/balance_sheet.png', bbox_inches='tight', dpi=300)
plt.close()

# 2. Generate Income Statement Image
fig, ax = plt.subplots(figsize=(6, 4))
ax.axis('tight')
ax.axis('off')
data_is = [
    ["Revenue", "$1,500,000"],
    ["Expenses", "$950,000"],
    ["Operating Profit", "$550,000"],
    ["Net Income", "$450,000"],
    ["EPS", "$2.10"]
]
df_is = pd.DataFrame(data_is, columns=["Metric", "Value"])
table_is = ax.table(cellText=df_is.values, colLabels=df_is.columns, loc='center', cellLoc='left')
table_is.scale(1, 2)
table_is.set_fontsize(14)
plt.title("Income Statement Q3", fontsize=16)
plt.savefig('sample_images/income_statement.png', bbox_inches='tight', dpi=300)
plt.close()

# 3. Generate a Chart Image
fig, ax = plt.subplots(figsize=(6, 4))
months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
revenue = [100, 120, 115, 140, 160, 190]
ax.plot(months, revenue, marker='o', linestyle='-', color='b', label='Revenue Trend')
ax.set_title("Monthly Revenue Growth", fontsize=16)
ax.set_xlabel("Months")
ax.set_ylabel("Revenue ($K)")
ax.grid(True)
ax.legend()
plt.savefig('sample_images/chart.png', bbox_inches='tight', dpi=300)
plt.close()

print("Successfully generated high-quality sample images.")
