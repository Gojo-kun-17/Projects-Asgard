AI Content Creator Agent using n8n
==================================

This project implements an automated AI content creation workflow built using **n8n Cloud**. The workflow reads topics from a **Google Sheet**, performs real-time research using the **Tavily Search API**, and generates platform-specific content using the **Groq LLM API**. The system automatically creates a **LinkedIn post, X (Twitter) post, and a short blog summary**, then updates the results back into the same Google Sheet and marks the topic as completed.

This workflow demonstrates end-to-end automation of research, AI content generation, and structured output storage using a no-code workflow automation platform.