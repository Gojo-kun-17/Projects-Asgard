import os
from crewai import Crew, Process
from agents import create_manager_agent, create_analyzer_agent, create_corrector_agent
from tasks import create_analysis_task, create_correction_task

def main():
    # Ensure OPENAI_API_KEY is available (Check environment variable)
    if "OPENAI_API_KEY" not in os.environ:
        print("Warning: OPENAI_API_KEY environment variable is not set.")
        print("Please set it before running. E.g., `set OPENAI_API_KEY=your_key` on Windows.")
    
    # The incorrect Python function as instructed for the test input
    input_code = """def fibonacci_iterative(n):
if n < 0:
return []
elif n == 1:
return [0]
elif n == 2:
return [0, 1]

fib_sequence = [0, 1]
for i in range(2, n):
next_fib = fib_sequence[-1] + fib_sequence[-2]
fib_sequence.append(next_fib)

return fib_sequence"""

    print("Initializing Agents...")
    # Initialize the three required agents
    manager = create_manager_agent()
    analyzer = create_analyzer_agent()
    corrector = create_corrector_agent()

    print("Initializing Tasks...")
    # Initialize the tasks and assign them to respective agents
    analysis_task = create_analysis_task(analyzer, input_code)
    correction_task = create_correction_task(corrector, input_code)

    print("Configuring Crew workflow...")
    # Configure the Crew:
    # - Using Process.sequential ensures Manager -> Code Analyzer -> Code Corrector flow conceptually (tasks run in order)
    # - Planning enabled as required
    crew = Crew(
        agents=[manager, analyzer, corrector],
        tasks=[analysis_task, correction_task],
        process=Process.sequential,
        planning=True,
        verbose=True
    )

    print("Starting Crew Execution. This may take a minute...\n")
    # Execute the crew and retrieve the final result
    result = crew.kickoff()

    print("\n" + "="*50)
    print("FINAL RESULT (Corrected Code):")
    print("="*50)
    print(result)

if __name__ == "__main__":
    main()
