from crewai_tools import CodeInterpreterTool

# The analyzer uses the CodeInterpreterTool to evaluate and inspect Python code.
code_interpreter_tool = CodeInterpreterTool()
