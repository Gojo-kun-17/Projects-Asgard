from crewai import Task
from textwrap import dedent

def create_analysis_task(agent, code):
    """
    Creates the Code Analysis Task.
    The Code Analyzer examines the input Python code and produces a structured list of errors.
    """
    return Task(
        description=dedent(f"""\
            Analyze the following Python code for any syntax errors, indentation problems, and logical mistakes.
            Use the CodeInterpreterTool to evaluate the code and understand its execution behavior.
            
            Input Python Code:
            ```python
            {code}
            ```
            
            Your task is to produce a structured, detailed list of all detected errors."""),
        expected_output="A structured list of detected errors detailing syntax, indentation, and logical issues.",
        agent=agent
    )

def create_correction_task(agent, code):
    """
    Creates the Code Correction Task.
    The Code Corrector receives the report from the analyzer and fixes the code.
    """
    return Task(
        description=dedent(f"""\
            Review the structured list of errors identified by the Code Analyzer Agent for the following code:
            
            Original Input Python Code:
            ```python
            {code}
            ```
            
            Fix all the identified errors (indentation, logical, and syntax).
            Ensure the corrected code runs flawlessly and accurately returns the Fibonacci sequence up to the nth term.
            Return ONLY the corrected Python code."""),
        expected_output="The final, corrected version of the Python code.",
        agent=agent
    )
