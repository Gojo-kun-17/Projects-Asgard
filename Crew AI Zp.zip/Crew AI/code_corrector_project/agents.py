from crewai import Agent
from tools import code_interpreter_tool

def create_manager_agent():
    """
    Creates and returns the Manager Agent.
    Role: Oversees the workflow, coordinates all agents, and ensures proper execution order.
    """
    return Agent(
        role='Manager Agent',
        goal='Oversee the code analysis and correction workflow, ensuring the analysis task runs before the correction task, and coordinate all agents.',
        backstory='An expert software engineering manager who excels at orchestrating developer teams and ensuring high-quality, bug-free code delivery.',
        allow_delegation=True,
        verbose=True
    )

def create_analyzer_agent():
    """
    Creates and returns the Code Analyzer Agent.
    Role: Responsible for analyzing Python code, identifying syntax, indentation, and logic errors.
    """
    return Agent(
        role='Code Analyzer Agent',
        goal='Analyze Python code thoroughly to identify syntax errors, indentation problems, and logical mistakes.',
        backstory='A meticulous senior QA engineer and Python expert. You use tools to execute and inspect code to find even the most subtle bugs.',
        tools=[code_interpreter_tool],
        allow_delegation=False,
        verbose=True
    )

def create_corrector_agent():
    """
    Creates and returns the Code Corrector Agent.
    Role: Receives the error report from the analyzer and fixes all issues in the original code.
    """
    return Agent(
        role='Code Corrector Agent',
        goal='Fix all errors identified by the Code Analyzer Agent and output the fully corrected, executable Python code.',
        backstory='A brilliant software engineer specializing in refactoring and fixing faulty Python code. You take error reports and produce flawless solutions.',
        allow_delegation=False,
        verbose=True
    )
