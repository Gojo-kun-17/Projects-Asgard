# CrewAI Code Corrector Project

## Project Objective
This project demonstrates a multi-agent AI system built with CrewAI. The system automatically analyzes faulty Python code, identifies errors (syntax, indentation, logic), and corrects them. It uses a structured workflow with specialized agents to simulate a real-world software engineering pipeline.

## Agents
The system consists of three distinct agents:
1. **Manager Agent**: Oversees the workflow, ensures tasks run in the correct order, and coordinates the other agents.
2. **Code Analyzer Agent**: A meticulous developer that examines the input code to spot syntax, indentation, and logical mistakes using the `CodeInterpreterTool`.
3. **Code Corrector Agent**: A brilliant engineer that takes the structured error report from the analyzer and writes the final, corrected Python code.

## Tasks
1. **Code Analysis Task**: Assigned to the Code Analyzer Agent. It takes the raw, faulty Python code and produces a detailed list of detected errors.
2. **Code Correction Task**: Assigned to the Code Corrector Agent. It receives the error list and the original code, refactoring and fixing it completely.

## Tools
- **CodeInterpreterTool**: Provided via `crewai_tools`, this tool allows the Code Analyzer to execute Python code in a safe environment to inspect variables, discover runtime errors, and verify its behavior dynamically.

## Execution Instructions
### Prerequisites
Ensure you have Python 3.10+ installed. Install the dependencies using:
```bash
pip install -r requirements.txt
```

### Environment Variable
You must provide an OpenAI API key for the agents to function. Set it as an environment variable:

**Windows:**
```cmd
set OPENAI_API_KEY=your_openai_api_key
```

**Linux/Mac:**
```bash
export OPENAI_API_KEY='your_openai_api_key'
```

### Running the Project
Once the dependencies are installed and the API key is set, simply execute:
```bash
python main.py
```
