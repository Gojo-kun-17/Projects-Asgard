import streamlit as st

# ----------------------------
# Page Config
# ----------------------------
st.set_page_config(page_title="AI Mock Interviewer", page_icon="🎯")

st.title("🎯 AI Mock Interviewer")
st.subheader("Role: Data Scientist")

st.write("Answer the following interview questions. You will receive instant feedback after each response.")

# ----------------------------
# Role-Specific Questions
# ----------------------------
questions = [
    "What is overfitting in machine learning and how can you prevent it?",
    "Explain the difference between regression and classification.",
    "What is cross-validation and why is it important?",
    "How does a decision tree algorithm work?",
    "What evaluation metrics would you use for a classification problem?",
    "Explain the bias-variance tradeoff."
]

# ----------------------------
# Session State Setup
# ----------------------------
if "question_index" not in st.session_state:
    st.session_state.question_index = 0

if "score" not in st.session_state:
    st.session_state.score = 0

# ----------------------------
# Feedback Logic
# ----------------------------
def generate_feedback(answer):
    word_count = len(answer.split())

    if word_count < 8:
        return "⚠️ Try to give more details about the concept."
    elif "example" not in answer.lower():
        return "👍 Good explanation! Try adding a real-world example."
    else:
        st.session_state.score += 1
        return "✅ Excellent answer with good clarity and example!"

# ----------------------------
# Interview Flow
# ----------------------------
if st.session_state.question_index < len(questions):

    current_question = questions[st.session_state.question_index]

    st.markdown(f"### Question {st.session_state.question_index + 1}")
    st.write(current_question)

    user_answer = st.text_area("Your Answer:")

    if st.button("Submit Answer"):
        if user_answer.strip() == "":
            st.warning("Please enter your answer before submitting.")
        else:
            feedback = generate_feedback(user_answer)
            st.success(feedback)
            st.session_state.question_index += 1

else:
    st.success("🎉 Interview Completed!")

    st.markdown("## 📊 Final Performance Summary")

    total_questions = len(questions)
    score = st.session_state.score

    st.write(f"Score: {score} / {total_questions}")

    if score >= 5:
        st.write("🌟 Excellent performance! You are well prepared.")
    elif score >= 3:
        st.write("👍 Good job! Some improvement can make you even better.")
    else:
        st.write("📘 Keep practicing! Focus on giving detailed answers with examples.")

    if st.button("Restart Interview"):
        st.session_state.question_index = 0
        st.session_state.score = 0