ML Project Submission

Files Included: 1. Project_Report.pdf - Project explanation 2.
Healthcare_Dataset.csv - Dataset used 3. model_training.py - Model
building script 4. requirements.txt - Required libraries

How to Run: 1. Install dependencies: pip install -r requirements.txt 2.
Run: python model_training.py
