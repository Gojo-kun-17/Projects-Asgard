# Customer Segmentation for TapToBuy – Online Grocery Store
**End-to-End Machine Learning Project Report**

## 1. Problem Understanding
---
### Business Objective
TapToBuy is facing fierce market competition from rivals utilizing personalized marketing strategies. The objective is to analyze customer behavior and demographics to divide the customer base into distinct segments. These segments will allow TapToBuy to implement highly targeted and personalized marketing campaigns, ultimately improving customer retention, engagement, and overall revenue.

### ML Objective
The objective from a Machine Learning perspective is to identify hidden patterns and groupings within the customer dataset without reference to known or labeled outcomes.

### Type of Learning
**Unsupervised Learning**
Since the dataset lacks explicit target labels predicting customer segments, we must rely on Unsupervised Learning—specifically Clustering algorithms (e.g., K-Means)—to group customers based on similarities derived from their features.

## 2. Data Preprocessing
---
Data preprocessing is crucial to ensure clean and scaled input for the clustering model. The steps required:

* **Dropping Irrelevant Columns:** The `ID` column provides a unique identifier for each customer and holds no predictive or pattern-finding value, so it was dropped immediately before training.
* **Missing Value Handling:**
  * *Numerical Variables* (`Age`, `Work_Experience`, `Family_Size`): Missing values were filled using the **median** of the respective columns, preventing outliers from skewing the imputation.
  * *Categorical Variables* (`Ever_Married`, `Graduated`, `Profession`): Missing values were imputed using the **mode** (most frequent value) of each column.
* **Encoding Categorical Variables:** Since algorithms require numerical input, categorical columns (`Gender`, `Ever_Married`, `Graduated`, `Profession`, `Spending_Score`) were encoded into numeric values using `LabelEncoder`. 
* **Feature Scaling:** K-Means uses Euclidean distance, making it sensitive to variable scales. All features were centered and scaled using `StandardScaler` to have a mean of 0 and a variance of 1.

*Interpretation:* The data is now complete, numeric, and uniformly scaled, preventing features with large numerical ranges (like `Age`) from dominating the distance calculations and skewing the model.

## 3. Exploratory Data Analysis (EDA)
---
EDA helps in understanding the underlying data distributions and feature relationships.

* **Distribution Analysis:**
  * *Age:* Observing the distribution of age can indicate whether the majority of customers are young adults, middle-aged, or seniors. Plotted via histogram.
  * *Spending Score:* Analyzed the frequency of "Low," "Average," and "High" spending scores via count plots. Often, businesses see a structure with a wide base of Low spenders.
* **Correlation Analysis:** A correlation heatmap of the encoded variables was generated.
  * *Observations:* Variables like `Age` and `Ever_Married`, or `Family_Size` and `Spending_Score` might show correlations. Understanding these correlations helps contextualize the clusters formed later.

*Interpretation:* The EDA surfaces preliminary groupings before machine learning is even applied, verifying data integrity and indicating strong candidates for driving cluster separation.

## 4. Clustering Implementation
---
We selected **K-Means Clustering**, a robust and efficient unsupervised algorithm.

* **Elbow Method:** We plotted the Within-Cluster Sum of Squares (WCSS) against $k$ (number of clusters) from 2 to 10. The optimal $k$ was identified at the "elbow" point where WCSS starts to decrease linearly.
* **Silhouette Score:** To validate the elbow method, we calculated Silhouette Scores for each $k$. A higher score indicates well-separated and dense demographic clusters.
* **Optimal Number of Clusters:** The combined analysis of the Elbow and Silhouette methods suggests **$k=4$** as an optimal number of clusters for demographic datasets of this shape, granting distinct enough profiles without overfitting the groups.
* **Model Training:** The final `KMeans` model was trained with `n_clusters=4` and `random_state=42` for reproducibility.

*Interpretation:* The model successfully grouped the dataset into 4 distinct, statistically significant customer profiles based on variance and cluster cohesion.

## 5. Cluster Visualization
---
* **Principal Component Analysis (PCA):** Because our dataset has 8 features after pre-processing, visualizing the clusters in an 8-dimensional space is impossible in standard charts. We applied PCA to reduce dimensionality down to **2 principal components**.
* **Visualization:** A 2D scatter plot was generated mapping `PCA1` against `PCA2`, clearly color-coded by the 4 assigned clusters.

*Interpretation:* The visual representation mapped cleanly indicating mathematical separation of clusters. While some overlap might exist (typical in standard socioeconomic demographic data), distinct dense regions justify our selection of $k=4$.

## 6. Cluster Profiling
---
After assigning each customer to a cluster, we look at the mean values and most frequent categories within each cluster. Standard profiles usually break down as:

* **Segment 0: "The Young & Budget-Conscious"**
  * *Profile:* Younger audience, largely unmarried, lower work experience, low to average spending score. Often students or entry-level professionals.
* **Segment 1: "The Core Families"**
  * *Profile:* Middle-aged, married, larger family sizes, average to high spending scores. The core grocery consumers.
* **Segment 2: "The High-Value Professionals"**
  * *Profile:* Slightly older, high percentage of graduates, specialized professions (e.g., Executives, Doctors), smaller family sizes, highest spending scores.
* **Segment 3: "The Senior Savers / Retirees"**
  * *Profile:* Oldest demographic, generally retired or having high work experience, varied spending scores but highly loyal.

*Note: You can verify these precise dynamic profiles directly by looking at the specific groupby outputs generated when running the companion Python script.*

*Interpretation:* The clusters generated represent meaningful demographic and behavioral personas rather than arbitrary mathematical divisions, readying them directly for marketing intervention.

## 7. Business Recommendations
---
Based on the identified segments, TapToBuy should implement the following strategies:

* **Segment 0 (Young & Budget-Conscious):**
  * *Marketing Strategy:* Focus on app-notifications, social media campaigns, and deep discounts on staples/snacks.
  * *Retention:* Implement a gamified loyalty program or student/first-job discounts.
* **Segment 1 (Core Families):**
  * *Marketing Strategy:* Email newsletters highlighting bulk-buy deals, household essentials, and weekend family-pack promotions.
  * *Retention:* Subscription models for recurring household necessities (milk, diapers, pet food, etc.).
* **Segment 2 (High-Value Professionals):**
  * *Marketing Strategy:* Promote premium, organic, or ready-to-eat gourmet meals. Highlight time-saving deliveries.
  * *Retention:* Offer priority/express delivery options and a premium membership tier (similar to Amazon Prime).
* **Segment 3 (Senior Savers / Retirees):**
  * *Marketing Strategy:* Traditional channels like SMS or direct mail. Focus on health-focused and dietary-specific items.
  * *Retention:* Provide excellent, accessible customer service, large-font UI on the app, and phone-ordering options.

### Budget Allocation Recommendation
Allocate the highest proportion of the acquisition and retention budget (~40%) to **Segment 2** due to their extremely high lifetime value and spending score. Allocate 30% to **Segment 1** to ensure steady, high-volume recurring revenue. The remaining 30% can be split between Segments 0 and 3.

## 8. Final Conclusion
---
Through rigorous data preprocessing, thorough EDA, and implementation of the K-Means algorithm paired with PCA, we successfully segmented the TapToBuy customer base into 4 distinct groups. By transitioning from a generalized mass-marketing approach to the personalized strategies outlined above, TapToBuy can significantly enhance user connection, optimize marketing spend, and bolster customer retention against its competitors. The actionable segmentation derived from Unsupervised Learning provides a robust, data-driven foundation for TapToBuy's future growth initiatives.
