

# ReAct Web Research Agent
# Author: Lakshana Venkatasamy
# Description: Implements a ReAct (Reasoning + Acting) agent using OpenAI LLM and Tavily web search

import os
from dotenv import load_dotenv
from openai import OpenAI
from tavily import TavilyClient

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")

llm_client = OpenAI(api_key=OPENAI_API_KEY)
tavily_client = TavilyClient(api_key=TAVILY_API_KEY)


class WebResearchAgent:

    def __init__(self, topic):
        self.topic = topic
        self.questions = []
        self.research_data = {}

    # Planning Phase (Reasoning)
    def generate_research_questions(self):
        prompt = f'''
        Generate 5-6 well-structured research questions about:
        "{self.topic}"

        Cover:
        - Background
        - Current Trends
        - Challenges
        - Applications
        - Future Scope

        Return numbered questions only.
        '''

        response = llm_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}]
        )

        output = response.choices[0].message.content
        self.questions = [q.strip() for q in output.split("\n") if q.strip()]
        return self.questions

    # Acting Phase (Web Search)
    def search_web(self, question):
        results = tavily_client.search(
            query=question,
            search_depth="advanced",
            max_results=3
        )

        extracted = []
        for result in results["results"]:
            extracted.append({
                "title": result.get("title", ""),
                "content": result.get("content", "")
            })
        return extracted

    def perform_research(self):
        for question in self.questions:
            self.research_data[question] = self.search_web(question)

    # Report Generation
    def generate_report(self):
        report = f"# Research Report: {self.topic}\n\n"
        report += "## Introduction\n"
        report += f"This report explores '{self.topic}' using a ReAct-based agent.\n\n"

        for question, results in self.research_data.items():
            report += f"## {question}\n"
            for item in results:
                report += f"### Source: {item['title']}\n"
                report += f"{item['content']}\n\n"

        report += "## Conclusion\n"
        report += f"The study covered multiple dimensions of {self.topic}.\n"

        return report


if __name__ == "__main__":
    topic = input("Enter research topic: ")
    agent = WebResearchAgent(topic)

    print("Generating research questions...")
    agent.generate_research_questions()

    print("Performing web research...")
    agent.perform_research()

    print("Generating final report...")
    report = agent.generate_report()

    with open("final_report.txt", "w", encoding="utf-8") as f:
        f.write(report)

    print("Report saved as final_report.txt")

