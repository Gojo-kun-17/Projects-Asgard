
Automated Code Debugging Assistant using CrewAI

Agents:
- Code Analyzer
- Code Corrector
- Manager

Features:
- Sequential task execution
- Planning enabled
- Error detection and correction

Input:
- Buggy Python code

Output:
- List of errors
- Corrected Python code

Note:
Set OPENAI_API_KEY before running.
