# Bill Management Agent System

This project implements an intelligent, multi-agent collaborative system for processing bill/receipt images using **Microsoft AutoGen**. It utilizes a simulated group discussion to automatically extract, categorize, and summarize expense data from a user-provided image.

## Agents overview

The system coordinates the following agents within a shared Group Chat:
1. **User Proxy Agent**: Initiates the workflow by providing the uploaded bill image to the Group Manager.
2. **Bill Processing Agent** (`MultimodalConversableAgent`): Analyzes the visual content of the bill to extract items, prices, and total amounts, and categorizes each item (e.g., Groceries, Dining, Utilities).
3. **Expense Summarization Agent**: Takes the structured data produced by the Bill Processor and computes category-wise spending patterns, identifying the highest-spending categories, and generating financial insights.
4. **Group Manager**: Enforces a strict sequential conversational workflow: User Proxy &rarr; Bill Processing Agent &rarr; Expense Summarization Agent.

---

## Setup Instructions

### 1. Install Dependencies
Ensure you have Python installed. Use `pip` to install the dependencies outlined in `requirements.txt`:

```bash
pip install -r requirements.txt
```

### 2. Configure OpenAI API Key
Since the Bill Processing Agent requires multimodal capabilities (vision), the system is configured to use the `gpt-4o` model by default. You must provide an OpenAI API Key.

**Windows (Command Prompt):**
```cmd
set OPENAI_API_KEY=your_openai_api_key_here
```

**Windows (PowerShell):**
```powershell
$env:OPENAI_API_KEY="your_openai_api_key_here"
```

**Mac/Linux:**
```bash
export OPENAI_API_KEY="your_openai_api_key_here"
```

---

## Running the System

You can run the agent workflow by passing the path of your bill image (either locally or a URL) to the `bill_manager.py` script.

```bash
# Example with a local image file
python bill_manager.py path/to/your/bill_image.jpg

# Example with an image URL
python bill_manager.py "https://example.com/receipt.jpg"
```

### Note on Expected Output Mode
The chat simulates a multi-agent dialogue in the terminal.
1. You will first see the **User Proxy Agent** trigger the request.
2. Then the **Bill Processing Agent** will output the *Itemized Expenses* and *Total Bill Amount*.
3. Finally, the **Expense Summarization Agent** will output the *Category-wise Spending Summary*, *Highest Spending Category*, and *Financial Insights*.

The outputs will be formatted specifically strictly following the rules defined for the system, formatting all amounts in Indian Rupees (₹).
