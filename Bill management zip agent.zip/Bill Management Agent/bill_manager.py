import os
import sys
import autogen
from autogen.agentchat.contrib.multimodal_conversable_agent import MultimodalConversableAgent

def get_config_list():
    """Retrieve the OpenAI configuration."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        print("Error: OPENAI_API_KEY environment variable is not set.", file=sys.stderr)
        print("Please set it before running the script.", file=sys.stderr)
        sys.exit(1)
        
    return [{"model": "gpt-4o", "api_key": api_key}]

def main():
    if len(sys.argv) < 2:
        print("Usage: python bill_manager.py <path_to_bill_image>")
        print("Example: python bill_manager.py sample_bill.jpg")
        sys.exit(1)
        
    image_path = sys.argv[1]
    
    if not os.path.exists(image_path) and not image_path.startswith("http"):
        print(f"Warning: The image file '{image_path}' might not exist locally.")

    config_list = get_config_list()
    
    # ====== 1. User Proxy Agent ======
    user_proxy = autogen.UserProxyAgent(
        name="User_Proxy_Agent",
        system_message="A human admin. Acts as the representative of the user and initiates the conversation.",
        human_input_mode="NEVER",
        max_consecutive_auto_reply=0,
        code_execution_config=False,
    )
    
    # ====== 2. Bill Processing Agent ======
    bill_processor = MultimodalConversableAgent(
        name="Bill_Processing_Agent",
        system_message="""You are the Bill Processing Agent. 
Your role is to analyze bill images and extract useful information.
You will receive messages with an image.
Extract product names and prices. Identify the total amount.
Categorize items into one of the following standard expense groups:
- Groceries
- Dining
- Utilities
- Shopping
- Entertainment
- Transport
- Others

EXPECTED OUTPUT FORMAT (Use precisely this format):
Bill Processed Successfully

Itemized Expenses
Item Name - Amount - Category
[List items here...]

Total Bill Amount: ₹[Total]

Return the structured categorized data for the Expense Summarization Agent.
Currency format must be Indian Rupees (₹).""",
        llm_config={"config_list": config_list, "temperature": 0.0, "max_tokens": 1000},
    )
    
    # ====== 3. Expense Summarization Agent ======
    expense_summarizer = autogen.AssistantAgent(
        name="Expense_Summarization_Agent",
        system_message="""You are the Expense Summarization Agent.
Your role is to analyze the categorized expense data provided by the Bill Processing Agent and provide insights.

Tasks:
1. Calculate total spending per category based on the provided list.
2. Identify the highest spending category.
3. Detect unusual or high spending patterns.
4. Provide a simple financial insight summary.

EXPECTED OUTPUT FORMAT (Use precisely this format):
Expense Summary Report

Category-wise Spending Summary
[List categories and totals here...]

Total Spending: ₹[Total]

Highest Spending Category: [Category]

Financial Insights
- [Insight 1]
- [Insight 2]

Do not include any other conversational filler. Provide only the requested output. Currency format must be Indian Rupees (₹).""",
        llm_config={"config_list": config_list, "temperature": 0.0},
    )

    # ====== 4. Group Manager ======
    # Enforces the sequential workflow: User -> Processor -> Summarizer
    groupchat = autogen.GroupChat(
        agents=[user_proxy, bill_processor, expense_summarizer],
        messages=[],
        max_round=3,
        speaker_selection_method="round_robin"
    )
    
    manager = autogen.GroupChatManager(
        groupchat=groupchat,
        name="Group_Manager",
        llm_config={"config_list": config_list},
    )
    
    # Initiation message from User Proxy Agent
    # We use <img ...> format for MultimodalConversableAgent to detect the image
    initial_message = f"""Hello Group Manager,
The user has uploaded a bill image for expense tracking.
Please forward this image to the Bill Processing Agent for extracting bill details and categorizing the expenses.

<img {image_path}>"""

    print(f"--- Starting Multi-Agent Bill Management Workflow for: {image_path} ---")
    user_proxy.initiate_chat(manager, message=initial_message)

if __name__ == "__main__":
    main()
