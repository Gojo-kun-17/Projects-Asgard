import os
from dotenv import load_dotenv

# Load environment variables (.env file)
load_dotenv()

# Check for required API keys (LangChain and Tavily)
if not os.getenv("OPENAI_API_KEY"):
    print("WARNING: OPENAI_API_KEY is not set in your .env file.")
if not os.getenv("TAVILY_API_KEY"):
    print("WARNING: TAVILY_API_KEY is not set in your .env file.")

from graph import graph_app

def run_system():
    print("="*60)
    print("LangGraph Multi-Agent Research & Summarization System")
    print("Type 'exit' or 'quit' to close the application.")
    print("="*60)
    
    # Configuration required by LangGraph MemorySaver to persist state in a thread
    config = {"configurable": {"thread_id": "user_session"}}
    
    while True:
        query = input("\n[User] Enter your query: ")
        
        if query.lower() in ["exit", "quit", "q"]:
            print("Exiting. Have a great day!")
            break
            
        print("\n[System] Processing... (routing, executing, summarizing)")
        
        try:
            # Invoke the graph workflow
            result = graph_app.invoke({"query": query}, config=config)
            
            print("\n" + "="*50)
            print(f"ROUTE TAKEN:  {result.get('route', 'unknown').upper()} AGENT")
            print("="*50)
            
            summary = result.get('final_summary', "No summary generated.")
            print(f"\n{summary}\n")
            print("="*50)
            
        except Exception as e:
            print(f"\n[Error] The system encountered an error: {e}\n")

if __name__ == "__main__":
    run_system()
