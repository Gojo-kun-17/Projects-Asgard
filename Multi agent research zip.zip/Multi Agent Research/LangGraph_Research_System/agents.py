import os
from langchain_openai import ChatOpenAI
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.messages import HumanMessage, AIMessage
from typing import TypedDict, Annotated, Sequence
import operator
from rag_setup import retriever

# Define the State for LangGraph
class GraphState(TypedDict):
    # messages accumulate the chat history
    messages: Annotated[list, operator.add]
    query: str
    route: str
    agent_response: str
    final_summary: str

# Initialize LLM
# We use gpt-4o-mini as it is fast and efficient for routing and reasoning
llm = ChatOpenAI(temperature=0, model="gpt-4o-mini")

def router_agent(state: GraphState):
    """
    Analyzes the user query and decides which agent should handle it.
    """
    query = state["query"]
    
    # Include history for context if available
    history = "\n".join([f"{type(m).__name__}: {m.content}" for m in state.get("messages", [])])
    
    prompt = f"""You are an intelligent router in a multi-agent system.
Analyze the user query and decide the best specialized agent to handle it.

Chat History:
{history}

Current Query: {query}

Choices:
1. 'web_search': If the query asks for the 'latest', 'current', 'news', 'today', or real-time information that requires internet scraping.
2. 'rag': If the query is about LangGraph, Transformers research, RAG, or existing stored documents.
3. 'llm': For general reasoning, math, physics, conceptual questions, or any standard conversational request.

Return ONLY ONE word strictly matching your choice ('web_search', 'rag', or 'llm').
"""
    response_msg = llm.invoke(prompt)
    route = response_msg.content.strip().lower()
    
    # Fallback/cleanup routing
    if "web_search" in route:
        route = "web_search"
    elif "rag" in route:
        route = "rag"
    else:
        route = "llm"
        
    return {"route": route, "messages": [HumanMessage(content=query)]}

def llm_agent(state: GraphState):
    """
    Handles general reasoning queries using the LLM.
    """
    query = state["query"]
    prompt = f"You are an expert AI reasoning agent. Answer the following conceptual/reasoning question thoughtfully and concisely.\n\nQuestion: {query}"
    response_msg = llm.invoke(prompt)
    return {"agent_response": response_msg.content}

def rag_agent(state: GraphState):
    """
    Retrieves information from a predefined FAISS dataset to answer the query.
    """
    query = state["query"]
    docs = retriever.invoke(query)
    context = "\n\n".join([d.page_content for d in docs])
    
    prompt = f"""You are a RAG agent. Using the following retrieved context, answer the scientific/document query.
If the answer is not in the context, do your best to answer accurately but state that it wasn't in the primary knowledge base.

Context:
{context}

Query: {query}"""
    response_msg = llm.invoke(prompt)
    return {"agent_response": response_msg.content}

def web_research_agent(state: GraphState):
    """
    Fetches real-time information from the internet using Tavily.
    """
    query = state["query"]
    try:
        search = TavilySearchResults(max_results=3)
        results = search.invoke(query)
        
        # Results is usually a list of dicts with 'url' and 'content'
        if isinstance(results, list):
            context = "\n".join([f"Source: {res.get('url', 'N/A')}\nContent: {res.get('content', '')}" for res in results])
            sources = "\n".join([res.get('url', 'N/A') for res in results])
        else:
            context = str(results)
            sources = "Tavily Search API"
            
        prompt = f"""You are a Web Research agent. Using the live search results below, answer the user's query about recent information.

Search Results:
{context}

Query: {query}"""
        response_msg = llm.invoke(prompt)
        response_with_sources = f"{response_msg.content}\n\nSources used:\n{sources}"
    except Exception as e:
        response_with_sources = f"Web search failed due to an error: {str(e)}"
        
    return {"agent_response": response_with_sources}

def summarizer_agent(state: GraphState):
    """
    Combines outputs from the executing agent and generates a structured response.
    """
    query = state["query"]
    agent_response = state["agent_response"]
    route_taken = state["route"]
    
    prompt = f"""You are the Summarization Agent. Combine the information provided by the {route_taken} agent and create a clear, structured final response for the user.

Original Query: {query}
Agent Response: {agent_response}

Format your output EXACTLY with these sections:

## Key Answer
[Brief, direct answer to the query]

## Supporting Information
[Detailed facts/reasoning from the agent's text]

## Sources
[Provide sources if the agent included them. Otherwise write "Knowledge Base" (if RAG) or "LLM Reasoning" (if LLM)]
"""
    response_msg = llm.invoke(prompt)
    summary = response_msg.content
    return {"final_summary": summary, "messages": [AIMessage(content=summary)]}
