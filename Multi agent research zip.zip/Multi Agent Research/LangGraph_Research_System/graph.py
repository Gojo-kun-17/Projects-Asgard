from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from agents import (
    GraphState, 
    router_agent, 
    llm_agent, 
    rag_agent, 
    web_research_agent, 
    summarizer_agent
)

def route_condition(state: GraphState):
    """
    Condition function to determine the next node based on router_agent's output.
    """
    return state["route"]

def build_graph():
    """
    Constructs the LangGraph architecture.
    """
    workflow = StateGraph(GraphState)
    
    # Add Nodes
    workflow.add_node("router_agent", router_agent)
    workflow.add_node("llm_agent", llm_agent)
    workflow.add_node("rag_agent", rag_agent)
    workflow.add_node("web_research_agent", web_research_agent)
    workflow.add_node("summarizer_agent", summarizer_agent)
    
    # Build Graph Flow
    workflow.set_entry_point("router_agent")
    
    # Conditional Routing from Router to specialized agents
    workflow.add_conditional_edges(
        "router_agent",
        route_condition,
        {
            "web_search": "web_research_agent",
            "rag": "rag_agent",
            "llm": "llm_agent"
        }
    )
    
    # Every specialized agent connects to the Summarizer agent
    workflow.add_edge("llm_agent", "summarizer_agent")
    workflow.add_edge("rag_agent", "summarizer_agent")
    workflow.add_edge("web_research_agent", "summarizer_agent")
    
    # Summarizer ends the flow
    workflow.add_edge("summarizer_agent", END)
    
    # Implement conversation memory
    memory = MemorySaver()
    app = workflow.compile(checkpointer=memory)
    
    return app

# Initialize compiled LangGraph app
graph_app = build_graph()
