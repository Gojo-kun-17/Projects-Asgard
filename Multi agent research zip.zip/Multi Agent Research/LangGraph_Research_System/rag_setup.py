import os
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings

def get_retriever():
    """
    Sets up the RAG retrieval system.
    Creates a sample dataset if it doesn't exist, extracts chunks, 
    embeds them using HuggingFace, and stores them in FAISS.
    """
    dataset_path = "sample_data.txt"
    
    # Create sample documents for RAG consisting of AI research info
    if not os.path.exists(dataset_path):
        with open(dataset_path, "w", encoding="utf-8") as f:
            f.write("""LangGraph is a library for building stateful, multi-actor applications with LLMs. It extends LangChain to allow for cyclical flows and state management across multiple steps.
Transformers are a deep learning architecture based on self-attention mechanisms, introduced in the research paper 'Attention Is All You Need' by Vaswani et al.
Transformers revolutionized NLP by allowing parallel processing of sequences, leading to models like BERT and GPT.
Retrieval-Augmented Generation (RAG) combines an information retrieval component with a text generator model. RAG helps fix hallucination by grounding the LLM's answers in a retrieved knowledge base.
""")
        
    loader = TextLoader(dataset_path)
    docs = loader.load()
    
    # Split document into chunks
    splitter = RecursiveCharacterTextSplitter(chunk_size=300, chunk_overlap=50)
    chunks = splitter.split_documents(docs)
    
    # Generate embeddings and store in FAISS
    # Using all-MiniLM-L6-v2 as it's small, fast and runs locally on CPU
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    vectorstore = FAISS.from_documents(chunks, embeddings)
    
    # Return as retriever, fetch top 2 chunks
    return vectorstore.as_retriever(search_kwargs={"k": 2})

# Initialize the retriever globally
retriever = get_retriever()
