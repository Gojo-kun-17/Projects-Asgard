import os
from crewai import Agent, Task, Crew, Process
from crewai.llm import LLM
from dotenv import load_dotenv

load_dotenv()

# ---------------------------
# LLM Configuration (OpenAI)
# ---------------------------
openai_llm = LLM(
    model="gpt-4o-mini",  # Change to "gpt-4o" if your plan allows
    temperature=0.3
)

# ---------------------------
# Code Analyzer Agent
# ---------------------------
code_analyzer = Agent(
    role="Code Analyzer",
    goal="Identify syntax and logical errors in Python code.",
    backstory="You are a senior Python developer specialized in debugging and identifying code issues.",
    llm=openai_llm,
    verbose=True
)

# ---------------------------
# Code Corrector Agent
# ---------------------------
code_corrector = Agent(
    role="Code Corrector",
    goal="Fix identified Python code errors and provide corrected code.",
    backstory="You are an expert Python engineer skilled in correcting code errors efficiently.",
    llm=openai_llm,
    verbose=True
)

# ---------------------------
# Manager Agent
# ---------------------------
manager = Agent(
    role="Manager",
    goal="Oversee the debugging process and ensure smooth execution between analyzer and corrector.",
    backstory="You supervise the debugging workflow and ensure high-quality output.",
    llm=openai_llm,
    verbose=True
)

# ---------------------------
# Example Input Code
# ---------------------------
input_code = """
def fibonacci_iterative(n):

    if n < 0:
        return []
    elif n == 1:
        return [0]
    elif n == 2:
        return [0, 1]

    fib_sequence = [0, 1]
    for i in range(2, n):
    next_fib = fib_sequence[-1] + fib_sequence[-2]
    fib_sequence.append(next_fib)
    return fib_sequence
"""

# ---------------------------
# Tasks
# ---------------------------
analysis_task = Task(
    description=f"""
    Analyze the following Python code and list all syntax and logical errors clearly:

    {input_code}
    """,
    agent=code_analyzer,
    expected_output="A clear list of identified syntax and logical errors."
)

correction_task = Task(
    description=f"""
    Based on the analysis, provide the fully corrected version of the following Python code:

    {input_code}
    """,
    agent=code_corrector,
    expected_output="The fully corrected Python code without errors."
)

# ---------------------------
# Crew Setup
# ---------------------------
crew = Crew(
    agents=[code_analyzer, code_corrector],
    tasks=[analysis_task, correction_task],
    manager=manager,
    process=Process.sequential,
    planning=True,
    verbose=True
)

# ---------------------------
# Run Crew
# ---------------------------
if __name__ == "__main__":
    result = crew.kickoff()
    print("\n\nFINAL OUTPUT:\n")
    print(result)
