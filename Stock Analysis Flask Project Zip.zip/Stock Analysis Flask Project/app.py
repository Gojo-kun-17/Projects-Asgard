from flask import Flask, jsonify, request
from config import config_by_name
from utils.data_fetcher import get_company_info, get_live_market_data, get_historical_data
from utils.analytics import analyze_stock_data
import os

def create_app(config_name='dev'):
    app = Flask(__name__)
    app.config.from_object(config_by_name[config_name])

    @app.errorhandler(400)
    def bad_request(error):
        return jsonify({"status": "error", "message": "Bad request!"}), 400

    @app.errorhandler(404)
    def not_found(error):
        return jsonify({"status": "error", "message": "Resource not found!"}), 404

    @app.errorhandler(500)
    def internal_server_error(error):
        return jsonify({"status": "error", "message": "Internal server error!"}), 500

    @app.route('/', methods=['GET'])
    def index():
        return jsonify({
            "message": "Welcome to Stock Market Analytics API",
            "endpoints": {
                "company_info": "GET /api/company/<symbol>",
                "live_market_data": "GET /api/market/live/<symbol>",
                "historical_data": "POST /api/market/historical",
                "analytics_insights": "POST /api/analytics/insights"
            }
        }), 200

    @app.route('/api/company/<string:symbol>', methods=['GET'])
    def company_info(symbol):
        result = get_company_info(symbol)
        if result["status"] == "error":
            return jsonify(result), 400
        return jsonify(result), 200

    @app.route('/api/market/live/<string:symbol>', methods=['GET'])
    def live_market_data(symbol):
        result = get_live_market_data(symbol)
        if result["status"] == "error":
            return jsonify(result), 400
        return jsonify(result), 200

    @app.route('/api/market/historical', methods=['POST'])
    def historical_data():
        if not request.is_json:
            return jsonify({"status": "error", "message": "Request must be JSON"}), 400
            
        data = request.get_json()
        symbol = data.get('symbol')
        start_date = data.get('start_date')
        end_date = data.get('end_date')
        
        if not all([symbol, start_date, end_date]):
            return jsonify({"status": "error", "message": "Missing required parameters: symbol, start_date, end_date"}), 400
            
        result = get_historical_data(symbol, start_date, end_date)
        if result["status"] == "error":
            return jsonify(result), 400
            
        return jsonify(result), 200

    @app.route('/api/analytics/insights', methods=['POST'])
    def analytics_insights():
        if not request.is_json:
            return jsonify({"status": "error", "message": "Request must be JSON"}), 400
            
        historical_data = request.get_json()
        
        # Validate format of historical data
        if not isinstance(historical_data, list):
            # Attempt to extract if nested under a key
            if isinstance(historical_data, dict) and 'historical_data' in historical_data:
                historical_data = historical_data['historical_data']
            else:
                return jsonify({"status": "error", "message": "Invalid JSON format. Expected a list of historical records."}), 400
                
        result = analyze_stock_data(historical_data)
        if result["status"] == "error":
            return jsonify(result), 400
            
        return jsonify(result), 200

    return app

app = create_app(os.getenv('FLASK_ENV', 'dev'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
