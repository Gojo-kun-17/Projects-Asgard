import yfinance as yf
from datetime import datetime

def get_company_info(symbol):
    """
    Fetches company information using yfinance.
    Returns full name, business summary, industry, sector, and key officers.
    """
    try:
        ticker = yf.Ticker(symbol)
        info = ticker.info
        
        if not info or 'longName' not in info:
            return {"status": "error", "message": "Company not found or data unavailable for the given symbol."}
        
        # Extract required fields
        company_data = {
            "symbol": symbol,
            "full_name": info.get("longName", "N/A"),
            "business_summary": info.get("longBusinessSummary", "N/A"),
            "industry": info.get("industry", "N/A"),
            "sector": info.get("sector", "N/A"),
            "key_officers": []
        }
        
        # Extract key officers (name and title)
        officers = info.get("companyOfficers", [])
        for officer in officers:
            company_data["key_officers"].append({
                "name": officer.get("name", "N/A"),
                "title": officer.get("title", "N/A")
            })
            
        return {"status": "success", "data": company_data}
    except Exception as e:
        return {"status": "error", "message": f"Failed to fetch company info: {str(e)}"}

def get_live_market_data(symbol):
    """
    Fetches real-time/current market data for the given symbol.
    """
    try:
        ticker = yf.Ticker(symbol)
        info = ticker.info
        
        if not info or ('regularMarketPrice' not in info and 'currentPrice' not in info):
            return {"status": "error", "message": "Stock not found or data unavailable."}
        
        # Sometimes 'currentPrice' might not be available for some indices/stocks
        # Fallback to 'regularMarketPrice' or 'previousClose' if needed
        current_price = info.get('currentPrice') or info.get('regularMarketPrice') or info.get('previousClose')
        previous_close = info.get('previousClose')
        
        price_change = None
        percentage_change = None
        if current_price and previous_close:
            price_change = current_price - previous_close
            percentage_change = (price_change / previous_close) * 100
            
        market_data = {
            "symbol": symbol,
            "market_state": info.get("marketState", "N/A"),
            "current_price": current_price,
            "price_change": round(price_change, 2) if price_change is not None else "N/A",
            "percentage_change": round(percentage_change, 2) if percentage_change is not None else "N/A",
            "day_high": info.get("dayHigh", "N/A"),
            "day_low": info.get("dayLow", "N/A"),
            "volume": info.get("volume", "N/A")
        }
        
        return {"status": "success", "data": market_data}
    except Exception as e:
        return {"status": "error", "message": f"Failed to fetch live market data: {str(e)}"}

def get_historical_data(symbol, start_date, end_date):
    """
    Fetches historical stock market data for the given date range.
    start_date and end_date should be in 'YYYY-MM-DD' format.
    """
    try:
        # Validate dates
        datetime.strptime(start_date, '%Y-%m-%d')
        datetime.strptime(end_date, '%Y-%m-%d')
        
        ticker = yf.Ticker(symbol)
        history = ticker.history(start=start_date, end=end_date)
        
        if history.empty:
            return {"status": "error", "message": "No data found for the given date range or symbol."}
            
        # Reset index to make Date a column and convert it to string
        history.reset_index(inplace=True)
        
        # Ensure 'Date' column is converted to string properly, handling naive/timezone-aware issues
        history['Date'] = history['Date'].dt.strftime('%Y-%m-%d')
        
        # Convert dataframe to list of dictionaries
        historical_data = history.to_dict(orient='records')
        
        return {"status": "success", "data": historical_data}
    except ValueError:
        return {"status": "error", "message": "Invalid date format. Use YYYY-MM-DD."}
    except Exception as e:
        return {"status": "error", "message": f"Failed to fetch historical data: {str(e)}"}
