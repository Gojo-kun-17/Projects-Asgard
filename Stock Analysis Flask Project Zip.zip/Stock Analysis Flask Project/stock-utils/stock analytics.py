import pandas as pd
import numpy as np

def analyze_stock_data(historical_data):
    """
    Accepts historical stock data as JSON (list of dicts)
    and performs analysis using pandas.
    """
    try:
        if not historical_data:
            return {"status": "error", "message": "No historical data provided."}
            
        # Create DataFrame
        df = pd.DataFrame(historical_data)
        
        # Check required columns
        if 'Close' not in df.columns:
            return {"status": "error", "message": "Data must contain 'Close' price."}
            
        # Ensure 'Close' is numeric
        df['Close'] = pd.to_numeric(df['Close'], errors='coerce')
        df.dropna(subset=['Close'], inplace=True)
        
        if df.empty:
            return {"status": "error", "message": "Invalid numerical data in 'Close'."}
            
        # Perform calculations
        avg_closing = df['Close'].mean()
        highest_closing = df['Close'].max()
        lowest_closing = df['Close'].min()
        
        # Trend analysis (compare first and last closing prices)
        if len(df) >= 2:
            first_close = df.iloc[0]['Close']
            last_close = df.iloc[-1]['Close']
            
            if last_close > first_close:
                trend = "Upward"
            elif last_close < first_close:
                trend = "Downward"
            else:
                trend = "Flat"
        else:
            trend = "Insufficient data for trend"
            
        insights = {
            "average_closing_price": float(round(avg_closing, 2)),
            "highest_closing_price": float(round(highest_closing, 2)),
            "lowest_closing_price": float(round(lowest_closing, 2)),
            "trend": trend
        }
        
        return {"status": "success", "data": insights}
    except Exception as e:
        return {"status": "error", "message": f"Failed to analyze data: {str(e)}"}
